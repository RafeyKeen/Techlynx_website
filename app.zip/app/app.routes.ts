import { NgModule } from '@angular/core';
import { Routes } from '@angular/router';  // Import Routes

import { MainPageComponent } from './main-page/main-page.component';
import { SolutionComponent } from './solution-section/solution-section.component';
import { CyberSecurityComponent } from './cyber-security/cyber-security.component';
import {ITServiceManagementComponent} from './itservice-management/itservice-management.component';
import { DigitalTransformationComponent } from './digital-tranformation/digital-transformation.component';
import { CloudSolutionComponent } from './cloud-solution/cloud-solution.component';
import { HospitalManagementComponent } from './hospital-management/hospital-management.component';
import { AboutUsComponent } from './about-us/about-us.component';
import { PartnersComponent } from './partners/partners.component';
import { AiServicesComponent } from './ai-services/ai-services.component';

export const routes: Routes = [
  { path: 'home', component: MainPageComponent },
  { path: 'solution', component: SolutionComponent },
  { path: 'about-us', component: AboutUsComponent},
  {path: 'partners', component: PartnersComponent},
  {path: 'cybersecurity', component: CyberSecurityComponent },  // Path for CyberSecurityComponent
  {path: 'it-services', component: ITServiceManagementComponent},
  {path: 'digital-transformation',component: DigitalTransformationComponent},
  {path: 'cloud-solution', component:CloudSolutionComponent},
  {path: 'hospital-management', component:HospitalManagementComponent},
  {path:'ai-services',component:AiServicesComponent},
  { path: '', redirectTo: '/home', pathMatch: 'full' },
  { path: '**', redirectTo: '/home', pathMatch: 'full' }
];
