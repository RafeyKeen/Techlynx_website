// partners.component.ts
import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { RouterModule } from '@angular/router';

@Component({
  selector: 'app-partners',
  standalone: true,
  imports: [RouterModule, CommonModule],
  templateUrl: './partners.component.html',
  styleUrl: './partners.component.css'
})
export class PartnersComponent {
  partners = [
    'assets/part1.png',
    'assets/part2.png',
    'assets/part3.png',
    'assets/part4.png',
    'assets/part5.png',
    'assets/part6.png',
    'assets/part7.png',
    'assets/part8.png',
    'assets/part9.png'
  ];
}