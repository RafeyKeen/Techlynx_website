import { Component, OnInit, ElementRef, AfterViewInit } from '@angular/core';
import { RouterModule } from '@angular/router';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-itservice-management',
  standalone: true,
  imports: [RouterModule, CommonModule],
  templateUrl: './itservice-management.component.html',
  styleUrls: ['./itservice-management.component.css']
})
export class ITServiceManagementComponent implements OnInit, AfterViewInit {
  constructor(private el: ElementRef) {}

  ngOnInit() {}

  ngAfterViewInit() {
    // Create intersection observer for scroll animations
    const observer = new IntersectionObserver((entries) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          entry.target.classList.add('show');
        }
      });
    }, {
      threshold: 0.15,
      rootMargin: '0px 0px -50px 0px'
    });

    // Observe all elements with reveal classes
    document.querySelectorAll('.reveal').forEach((element) => {
      observer.observe(element);
    });
  }
}