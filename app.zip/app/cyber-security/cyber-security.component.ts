import { AfterViewInit, Component, ElementRef, ViewChild, OnInit } from '@angular/core';
import { RouterModule, Router, NavigationEnd, ActivatedRoute } from '@angular/router';
import { filter } from 'rxjs/operators';

@Component({
    selector: 'app-cyber-security',
    standalone: true,
    imports: [RouterModule],
    templateUrl: './cyber-security.component.html',
    styleUrls: ['./cyber-security.component.css']
})
export class CyberSecurityComponent implements OnInit, AfterViewInit {
    @ViewChild('backgroundVideo') backgroundVideo!: ElementRef;
    private observer: IntersectionObserver | undefined;
    
    constructor(
        private router: Router,
        private route: ActivatedRoute
    ) {}

    ngOnInit() {
        // Subscribe to router events
        this.router.events.pipe(
            filter(event => event instanceof NavigationEnd)
        ).subscribe(() => {
            if (this.router.url.includes('cyber-security')) {
                // Force scroll to top and reload
                window.scrollTo(0, 0);
                // Add a small delay before reload to ensure scroll takes effect
                setTimeout(() => {
                    window.location.reload();
                }, 100);
            }
        });

        // Ensure scroll position is at top on direct navigation
        window.scrollTo(0, 0);
        
        this.setupIntersectionObserver();
    }

    ngAfterViewInit() {
        // Ensure scroll position is at top after view initialization
        window.scrollTo(0, 0);
        
        if (this.backgroundVideo && this.backgroundVideo.nativeElement) {
            this.backgroundVideo.nativeElement.play().catch((error: unknown) => {
                console.error('Error attempting to play the video:', error);
            });
        }

        // Add slide-up animation to service texts
        const serviceTexts = document.querySelectorAll('.service-text');
        serviceTexts.forEach((text, index) => {
            setTimeout(() => {
                text.classList.add('slide-up');
            }, index * 500); // Stagger the animations
        });
    }

    private setupIntersectionObserver() {
        this.observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    entry.target.classList.add('in-view');
                    
                    // Add slide-up animation when service texts come into view
                    const serviceTexts = entry.target.querySelectorAll('.service-text');
                    serviceTexts.forEach((text, index) => {
                        setTimeout(() => {
                            text.classList.add('slide-up');
                        }, index * 500);
                    });
                }
            });
        }, {
            threshold: 0.1
        });

        setTimeout(() => {
            const imageContainers = document.querySelectorAll('.image-container');
            imageContainers.forEach(container => {
                if (this.observer) {
                    this.observer.observe(container);
                }
            });
        });
    }

    ngOnDestroy() {
        if (this.observer) {
            this.observer.disconnect();
        }
    }
}