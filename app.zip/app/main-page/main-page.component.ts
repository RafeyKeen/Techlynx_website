import { Component, ElementRef, ViewChild, AfterViewInit } from '@angular/core';
import { Router, RouterModule } from '@angular/router';

@Component({
  selector: 'app-main-page',
  standalone: true,
  imports: [RouterModule],
  templateUrl: './main-page.component.html',
  styleUrls: ['./main-page.component.css']
})
export class MainPageComponent implements AfterViewInit {
  @ViewChild('backgroundVideo') backgroundVideo!: ElementRef;

  constructor(private router: Router) {}

  ngAfterViewInit() {
    if (this.backgroundVideo && this.backgroundVideo.nativeElement) {
      this.backgroundVideo.nativeElement.play().catch((error: unknown) => {
        console.error('Error attempting to play the video:', error);
      });
    }
  }

  navigateToSolution() {
    this.router.navigate(['solutions']);
  }
}