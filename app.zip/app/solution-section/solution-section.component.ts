import { Component, AfterViewInit } from '@angular/core';
import { RouterModule, Router } from '@angular/router';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-solutions',
  standalone: true,
  imports: [RouterModule, CommonModule],
  templateUrl: './solution-section.component.html',
  styleUrls: ['./solution-section.component.css']
})
export class SolutionComponent implements AfterViewInit {
  
  constructor(private router: Router) {}

  solutions = [
    {
      title: 'IT Service & Operations Management',
      description: 'Techlynx streamlines IT operations by offering help desk support, asset management, system monitoring, and security with intuitive dashboards.',
      image: 'assets/IT sol.jpg',
      alignment: 'left'
    },
    {
      title: 'Cybersecurity',
      description: 'Techlynx secures your business by detecting and addressing cyber threats in real-time, while testing applications for vulnerabilities to prevent attacks.',
      image: 'assets/cyber_security.jpg',
      alignment: 'right'
    },
    {
      title: 'Digital Transformation',
      description: 'Techlynx creates websites, apps, and platforms, automates workflows, and uses data analytics to improve decision-making and drive growth.',
      image: 'assets/Digital_transformation.jpg',
      alignment: 'left'
    },
    {
      title: 'Cloud Solutions',
      description: 'Techlynx provides customized cloud solutions, ensuring secure, scalable, and mobile-friendly environments with full management for reliable performance.',
      image: 'assets/cloud_sol.jpg',
      alignment: 'right'
    },
    {
      title: 'Hospital Information Management System',
      description: 'A HIPAA-compliant health automation system streamlining patient care, hospital operations, and service delivery with integrated standards and cloud/on-prem options.',
      image: 'assets/hospital.jpg',
      alignment: 'left'
    },
    {
      title: 'AI Services',
      description: 'Techlynx leverages artificial intelligence to deliver smart automation, predictive analytics, and intelligent solutions that transform business operations and decision-making capabilities.',
      image: 'assets/AI_pic.jpg',
      alignment: 'left'
    }
  ];

  ngAfterViewInit() {
    this.setupIntersectionObserver();
  }

  private setupIntersectionObserver() {
    const options = {
      root: null,
      rootMargin: '0px',
      threshold: 0.1
    };

    const observer = new IntersectionObserver((entries) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          entry.target.classList.add('visible');
        }
      });
    }, options);

    document.querySelectorAll('.solution-item').forEach(item => observer.observe(item));
  }

  navigateToSolution(solutionTitle: string) {
    let route: string;

    switch (solutionTitle.toLowerCase()) {
      case 'cybersecurity':
        route = '/cybersecurity';
        break;
      case 'it service & operations management':
        route = '/it-services';
        break;
      case 'digital transformation':
        route = '/digital-transformation';
        break;
      case 'cloud solutions':
        route = '/cloud-solution';
        break;
      case 'hospital information management system':
        route = '/hospital-management';
        break;
      case 'ai services':
        route = '/ai-services';
        break;
      default:
        route = '/solutions';
        break;
    }

    this.router.navigate([route]).then(() => {
      window.scrollTo(0, 0);
    });
  }
}