// digital-transformation.component.ts
import { Component, OnInit, ViewChild, ElementRef, AfterViewInit } from '@angular/core';
import { RouterModule } from '@angular/router';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-digital-tranformation',
  standalone: true,      
  imports: [RouterModule, CommonModule],                                                                 
  templateUrl: './digital-transformation.component.html',
  styleUrls: ['./digital-transformation.component.css']
})
export class DigitalTransformationComponent implements OnInit, AfterViewInit {
  @ViewChild('videoPlayer') videoPlayer!: ElementRef<HTMLVideoElement>;

  ngOnInit(): void {
    if (this.videoPlayer) {
      this.videoPlayer.nativeElement.play();
    }
  }

  ngAfterViewInit() {
    // Create intersection observer for scroll animations
    const observer = new IntersectionObserver((entries) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          entry.target.classList.add('show');
        }
      });
    }, {
      threshold: 0.15,
      rootMargin: '0px 0px -50px 0px'
    });

    // Observe all elements with reveal classes
    document.querySelectorAll('.reveal').forEach((element) => {
      observer.observe(element);
    });
  }
}