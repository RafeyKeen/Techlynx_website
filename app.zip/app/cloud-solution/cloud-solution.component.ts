// cloud-solution.component.ts
import { AfterViewInit, Component, ElementRef, ViewChild, OnInit } from '@angular/core';
import { RouterModule } from '@angular/router';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-cloud-solution',
  standalone: true,
  imports: [RouterModule, CommonModule],
  templateUrl: './cloud-solution.component.html',
  styleUrl: './cloud-solution.component.css'
})
export class CloudSolutionComponent implements AfterViewInit {
  constructor() {}

  ngAfterViewInit() {
    // Create intersection observer
    const observer = new IntersectionObserver((entries) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          entry.target.classList.add('show');
          // Optional: unobserve after animation
          // observer.unobserve(entry.target);
        }
      });
    }, {
      threshold: 0.1 // Trigger when 10% of the element is visible
    });

    // Observe all elements with the 'reveal' class
    document.querySelectorAll('.reveal').forEach((element) => {
      observer.observe(element);
    });
  }
}