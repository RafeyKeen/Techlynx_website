import { Component, OnInit, ViewChild, ElementRef, AfterViewInit } from '@angular/core';
import { RouterModule } from '@angular/router';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-hospital-management',
  standalone: true,
  imports: [RouterModule, CommonModule],
  templateUrl: './hospital-management.component.html',
  styleUrls: ['./hospital-management.component.css']
})
export class HospitalManagementComponent implements OnInit, AfterViewInit {
  @ViewChild('backgroundVideo') backgroundVideo!: ElementRef<HTMLVideoElement>;

  ngOnInit(): void {
    // Initial setup when component initializes
    this.initializeVideo();
  }

  ngAfterViewInit() {
    // Ensure video is muted after view initialization
    this.initializeVideo();

    // Create intersection observer for scroll animations
    const observer = new IntersectionObserver((entries) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          entry.target.classList.add('show');
        }
      });
    }, {
      threshold: 0.15,
      rootMargin: '0px 0px -50px 0px'
    });

    // Observe all elements with reveal classes
    document.querySelectorAll('.reveal').forEach((element) => {
      observer.observe(element);
    });
  }

  private initializeVideo(): void {
    if (this.backgroundVideo) {
      const video = this.backgroundVideo.nativeElement;
      
      // Force mute the video
      video.muted = true;
      video.defaultMuted = true;
      
      // Add event listener to ensure muting persists
      video.addEventListener('play', () => {
        video.muted = true;
      });

      // Start playing
      video.play().catch(error => {
        console.log('Auto-play prevented:', error);
      });
    }
  }
}