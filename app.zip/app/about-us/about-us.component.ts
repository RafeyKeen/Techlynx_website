import { CommonModule } from '@angular/common';
import { Component, OnInit, ElementRef, Renderer2 } from '@angular/core';
import { RouterModule } from '@angular/router';

@Component({
  selector: 'app-about-us',
  standalone: true,
  imports: [RouterModule, CommonModule],
  templateUrl: './about-us.component.html',
  styleUrls: ['./about-us.component.css']
})
export class AboutUsComponent implements OnInit {
  constructor(private el: ElementRef, private renderer: Renderer2) {}

  ngOnInit() {
    // Optional: If you want to trigger animation on page load
    this.animateSection();
  }

  animateSection() {
    const container = this.el.nativeElement.querySelector('.about-us-container');
    const upperSection = container.querySelector('.upper-section');
    const lowerSection = container.querySelector('.lower-section');

    // Add animation classes
    this.renderer.addClass(upperSection, 'slide-down');
    this.renderer.addClass(lowerSection, 'slide-up');
  }
}